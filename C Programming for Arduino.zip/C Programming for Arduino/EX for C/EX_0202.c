/*
/ Program: EX_0202.c
/ Purpose: static variables
*/

#include <stdio.h>
#include <conio.h>

int cntIn(void)
{
	static int cnt = 0;
	cnt++;
	return (cnt);
}

int main(void)
{
	int n;
	
	printf("static variables\n\n");
	n = cntIn();
	printf("Call cntIn() 1st n = %d\n", n);
	n = cntIn();
	printf("Call cntIn() 2nd n = %d\n", n);
	n = cntIn();
	printf("Call cntIn() 3rd n = %d\n", n);
	getchar();
}
