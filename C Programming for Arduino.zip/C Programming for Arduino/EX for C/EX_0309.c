/*
/ Program: EX_0309.c
/ purpose: Shift Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 10;	// 0000 1010 (binary number)
    b = 3;	// 0000 0011
    
    printf("\nShift Operators\n\n");
    
    printf("a = %2d (0x%X)\nb = %2d (0x%X)\n\n", a, a, b, b);
    
    printf("a << 1 = %2d (0x%X)\n", a << 1, a << 1);
    printf("a << 2 = %2d (0x%X)\n\n", a << 2, a << 2);

    printf("b >> 1 = %2d (0x%X)\n", b >> 1, b >> 1);
    printf("b >> 2 = %2d (0x%X)\n", b >> 2, b >> 2);
    			
    getchar();
    return 1;
}

