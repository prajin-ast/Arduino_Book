/*
/ Program: EX_0303.c
/ Purpose: Main&Sub function
*/

#include <stdio.h>
#include <conio.h>

// Line function
void line(void)
{
	printf("=======================\n");
}

// Main Function (Main Program)
int main (void)
{
	line();
	printf("Main Function...\n");
	line();
	printf("number 1...\n");
	line();
	printf("number 2...\n");
	line();
	
    getchar();
    return 1;
}
