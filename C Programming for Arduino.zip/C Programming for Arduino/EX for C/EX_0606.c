/*
/ Program: EX_0606.c
/ Purpose: String
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i = 0;
    char str1[] = "C for MCU";
    char str2[] = {'C',' ','f','o','r',' ','M','C','U','\0'};
    
    printf("\nString (array character)\n\n");
    
    printf("char str1[] = \"C for MCU\";\n\n");
    printf("str1: %s\n\n",str1);
    
    printf("char str2[] = {'C',' ','f','o','r',' ','M','C','U',\'\\0\'};\n\n");
    printf("str2: ");
    while(str2[i] != '\0')
    {
        printf("%c",str2[i]);
        i++;
    }    
    printf("\n");
    
    getchar();
    return 1;
}
