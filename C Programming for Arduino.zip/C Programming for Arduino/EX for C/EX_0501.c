/*
/ Program: EX_0501.c
/ Purpose: pass by value & pass by ref program
*/

#include <stdio.h>
#include <conio.h>

// Preprocessor directives
#define TRUE 1

// Function func01
void func01(void)
{
	printf("in..func01\n");
}

// Function func02 (pass by value & return data)
int func02(int x, int y)
{
    int z;

    z = x+y;
    printf("in..func02 z = %d\n",z);
    return(z);
}

// Function func03 (pass by value)
void func03(int x, int y)
{
    int z;

    z = 10;
    x = x + z;
    y = y + z;
    printf("in:     x = %d, y = %d\n",x,y);
}

// Function func04 (pass by reference)
void func04(int *x, int *y)
{
    int z;

    z = 10;
    *x = *x + z;
    *y = *y + z;
    printf("in:     x = %d, y = %d\n",*x,*y);
} 

// Main Function (Main Program)
int main (void)
{
    int i,j,k;

    i = 10;
    j = 20;

    func01();
    k = func02(i, j);
    printf("in..main   k = %d",k);

    printf("\n\nPass by Value func03\n\n");
    printf("before: i = %d, j = %d \n",i,j);
    func03(i, j);
    printf("after:  i = %d, j = %d\n",i,j);

    printf("\n\nPass by Reference func04\n\n");
    printf("before: i = %d, j = %d\n",i,j);
    func04(&i, &j);
    printf("after:  i = %d, j = %d\n",i,j);
    
    getchar();
    return 1;
}
