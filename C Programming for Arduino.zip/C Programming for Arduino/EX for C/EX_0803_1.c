/*
/ program: EX_0803_1.c
/ purpose: union data type
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    union IntOrLong
    {
        int i;
        double d;
    }a_num;

    char cc;
    int ii;
    long ll;
    float ff;
    double dd;
    
    printf("union data type\n\n");
    printf("--------------------\n");
    printf("union IntDouble\n");
    printf("{\n");
    printf("    int i;\n");
    printf("    double d;\n");
    printf("}\n");
    printf("Size of Union = %d\n", sizeof(a_num));
    printf("--------------------\n\n");
    printf("Size of Varibables\n");
    printf("Size of char   = %d\n", sizeof(cc));
    printf("Size of int    = %d\n", sizeof(ii));
    printf("Size of long   = %d\n", sizeof(ll));
    printf("Size of float  = %d\n", sizeof(ff));
    printf("Size of double = %d\n", sizeof(dd));
    
    
    getch();
}
