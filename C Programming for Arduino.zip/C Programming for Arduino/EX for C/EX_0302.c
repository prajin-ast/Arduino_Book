/*
/ Program: EX_0302.c
/ purpose: Arithmetic & Unary Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;
    b = 3;

    c = a * b;  // Multiplication Operation
    printf("c = %d\n", c);
    
    c = a / b;  // Division Operation
    printf("c = %d\n", c);
    
    c = a % b;	// Modulo Operation
	printf("c = %d\n", c);
		
    getchar();
    return 1;
}

