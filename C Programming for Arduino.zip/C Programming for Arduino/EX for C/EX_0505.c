/*
/ Program: EX_0505.c
/ Purpose: Pass by Reference
*/

#include <stdio.h>
#include <conio.h>

// swap01 function (pass by value)
void swap01(int x, int y)
{
     int tmp;
     
     tmp = x;
     x = y;
     y = tmp;
}

// swap02 function (pass by reference)
void swap02(int *x, int *y)
{
     int tmp;
     
     tmp = *x;
     *x = *y;
     *y = tmp;
}

// Main Function (Main Program)
int main (void)
{
    int i, j;
    
    i = 10;
    j = 20;
    
    printf("Swap Function\n\n");
    printf("Start.. \n");
    printf("i = %d, j = %d\n\n", i, j);
    
    printf("swap 01 run.\n");
    swap01(i ,j);
	printf("i = %d , j = %d\n\n", i, j);
	
    printf("swap 02 run.\n");
    swap02(&i ,&j);
	printf("i = %d , j = %d\n\n", i, j);	
	
    getchar();
    return 1;
}
