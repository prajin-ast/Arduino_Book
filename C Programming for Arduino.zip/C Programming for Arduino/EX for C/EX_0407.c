/*
/ Program: EX_0407.c
/ purpose: for loop
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i;
	
    printf("\nfor loop\n\n");
        
    printf("Start..\n\n");    	
    for(i=0; i<5; i++)
    {
		printf("i = %d\n", i);
	}
	printf("\nEnd..\n");
		
    getchar();
    return 1;
}
