/*
/ Program: EX_0203.c
/ Purpose: enum variables
*/

#include <stdio.h> 
#include <conio.h>

int main(void)
{
	enum boolean {NO, YES};
	int i;

	printf("enum variables\n\n");	
	i = YES;
	//i = NO;
	printf("i = %d\n", i);
	
	if (i == YES)
	{
		printf("Yes\n");
	} else
	{
		printf("No\n");
	}
	
	getchar();
	return 1;
}
