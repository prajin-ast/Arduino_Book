/*
/ Program: EX_0405_1.c
/ purpose: switch statement 
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a;
    int b;

    a = 15;
    b = 15;
    
    printf("\nswitch statement \n\n");
    printf("a = %d\n\n", a);
    
    printf("Start..\n\n");
    switch(a == b)
    {
		case 0:
			printf("case a is 0\n");
		break;
		case 1:
			printf("case a is 1\n");
			break;
		case 10:
			printf("case a is 10\n");
		break;
		case 3:
			printf("case a is 3\n");
		break;
		default:
			printf("No case..\n");
		break;
	}
	printf("\nEnd..\n");
		
    getchar();
    return 1;
}
