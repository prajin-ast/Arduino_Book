/*
/ Program: EX_0702.c
/ Purpose: Operator Pointers
*/

#include <stdio.h>
#include <conio.h>
#include <string.h>

int main(void)
{
    char *sPtr = "C Programming for MCU";    
    int len, i;
    
    printf("String = %s\n",sPtr);
    len = strlen(sPtr);
    printf("length = %d\n",len);
    
    printf("\nOperator ++");
    printf("\nAddress Begin = %d\n",sPtr);
    for(i=0; i<len; i++)
    {
        printf("%c",*sPtr++);
    }
    printf("\nAddress End = %d",sPtr);
    
    printf("\n\nOperator --");
    sPtr--;
    printf("\nAddress Begin = %d\n",sPtr);
    for(i=len; i>0; i--)
    {
        printf("%c",*sPtr--);
    }
    printf("\nAddress End = %d",sPtr);
    
    getch();
}
