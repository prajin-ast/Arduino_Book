/*
/ Program: EX_0410.c
/ purpose: break loop
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i = 0;
	
    printf("\nBreak loop\n\n");    
	    
    printf("Start.. loop\n\n");    	
    do
    {			
		if (i > 5)
		{
			printf("Break..\n");
			break;
		}		
		i++;
		printf("i = %d\n", i);
	} while(i<10);
	printf("\nEnd.. loop\n");

    getchar();
    return 1;
}
