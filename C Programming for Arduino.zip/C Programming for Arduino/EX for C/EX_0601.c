/*
/ Program: EX_0601.c
/ Purpose: Array one dimension
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int n[5];
    
    n[0] = 10;
    n[1] = 20;
    n[2] = 30;
    n[3] = 40;
    n[4] = 50;
    
    printf("Array one dimension.. \n\n");
    
    printf("n[0] = %d\n",n[0]);
    printf("n[1] = %d\n",n[1]);
    printf("n[2] = %d\n",n[2]);
    printf("n[3] = %d\n",n[3]);
    printf("n[4] = %d\n",n[4]);
	
    getchar();
    return 1;
}
