/*
/ program: EX_0802.c
/ purpose: Pointer to Structure
*/

#include <stdio.h>
#include <string.h>
#include <conio.h>

struct str_idname
{
    int id;
    char name[80];
} sname, *ptrSname;

int main(void)
{
    strcpy(sname.name, "Mr Structures");
    sname.id = 500;
    printf("Structure\n");
    printf("Name: %s\n",sname.name);
    printf("Id: %d\n",sname.id);
    
    ptrSname = &sname;          // pointer to sname Structure              
    ptrSname->id = 1000;
    strcpy(ptrSname->name, "Mr Pointer to Structures");    
    printf("\nName: %s\n",sname.name);
    printf("Id: %d\n",sname.id);
    
    printf("\nPointer to Structure\n");
    printf("Name: %s\n",ptrSname->name);
    printf("Id: %d",ptrSname->id);
    
    getch();
}
