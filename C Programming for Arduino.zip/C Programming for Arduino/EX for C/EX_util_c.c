/*
/ program: EX_util_c.c
/ purpose: Utility for C
*/

#include <stdio.h>
#include <conio.h>

// Ref. Programming with C: Byron S. Gottfried
void dsp_bit_pattern(int i);

void dsp_bit_pattern(int i)
{
    int b, m, count, nbits;
    unsigned mask;
    
    //nbits = 8 * sizeof(int);
    nbits = 8 * sizeof(char);
    m = 0x1 << (nbits -1);
    mask = m;
    for(count=1; count<=nbits; count++)
    {
        b = (i&mask) ? 1:0;
        printf("%d", b);
        if (count % 4 == 0)
        {
            //printf(" ");
        }
        mask >>= 1;
    }
    printf("\n\r");
}
