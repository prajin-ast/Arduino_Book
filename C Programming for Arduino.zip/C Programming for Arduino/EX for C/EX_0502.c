/*
/ Program: EX_0302.c
/ Purpose: Main function
*/

#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
	printf("=======================\n");
	printf("Main Function...\n");
	printf("=======================\n");
	
    getchar();
    return 1;
}
