/*
/ EX_0102.c
/ c simple program
*/

#include <stdio.h>
#include <conio.h>

// Main Function
int main() 
{
	printf("Hello C Programming Easy..\a");
	getchar();
}
