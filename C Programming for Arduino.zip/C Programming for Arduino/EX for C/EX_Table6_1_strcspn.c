/*
/ Program: EX_Table6_1_strrchr.c
/ Purpose: strcspn
/ Ref:     Turbo C bible
*/
 
#include <stdio.h>
#include <conio.h>
#include <string.h>

// Main Function (Main Program)
int main (void)
{
    char s1[] = { "xza" };
		char s2[] = { "1234a567890" };
		int i;

    i = strcspn(s1, s2);
    printf("strcspn: %d\n\n",i);
    
    printf("\n");
    
    getchar();
    return 1;
}
