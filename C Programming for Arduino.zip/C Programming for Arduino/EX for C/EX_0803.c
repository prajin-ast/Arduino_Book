/*
/ program: EX_0803.c
/ purpose: union data type
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    union intLong
    {
        int i;
        double d;
    }a_num;

    printf("union data type\n\n");
    printf("Size of Union = %d\n\n", sizeof(a_num));
    
    printf("Use Integer in Union\n");
    a_num.i = 1000;
    printf("a_num.i: %d\n",a_num.i);
    
    printf("\nUse Double in Union\n");
    a_num.d = 1000.25;
    printf("a_num.d: %.2f\n",a_num.d);

    getch();
}
