/*
/ Program: EX_0301.c
/ purpose: Arithmetic & Unary Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;
    b = 3;
    
    c = a + b;  // Addition Operation
    printf("c = %d\n", c);
    c = -c;     // Negative Operation
	printf("c = %d\n", c);
		
    getchar();
    return 1;
}

