/*
/ Program: EX_0409.c
/ purpose: goto label
*/
 
#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i = 0;

    printf("\nGoto..Label\n\n");    

    printf("Start.. loop\n\n");    	
    do 
    {		
        if (i > 5)
        {
            printf("Goto..\n");
            goto ABC;	
        }
        printf("i = %d\n", i);
        i++;
    } while(i<10);
    printf("\nEnd.. loop\n");
	
ABC:
    printf("\nLabel ABC\n");
	
    getchar();
    return 1;
}
