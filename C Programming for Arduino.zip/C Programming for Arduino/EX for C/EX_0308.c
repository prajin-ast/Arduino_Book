/*
/ Program: EX_0308.c
/ purpose: Bitwise Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    unsigned char a, b;

    a = 10;	// 0000 1010 (binary number)
    b = 3;	// 0000 0011
    
    printf("\nBitwise Operators\n\n");
    
    printf("a = %3d (0x%X)\nb = %3d (0x%X)\n\n", a, a, b, b);
    
    printf("a & b = %3d (0x%X)\n", a & b, a & b);
    printf("a | b = %3d (0x%X)\n", a | b, a | b);
    printf("a ^ b = %3d (0x%X)\n", a ^ b, a ^ b);
    printf("~a    = %3d (0x%X)\n", (unsigned char) ~a, (unsigned char) ~a);
    printf("~b    = %3d (0x%X)\n", (unsigned char) ~b, (unsigned char) ~b);
			
    getchar();
    return 1;
}

