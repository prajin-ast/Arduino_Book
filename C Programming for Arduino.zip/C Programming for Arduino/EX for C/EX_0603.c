/*
/ Program: EX_0603.c
/ Purpose: Array one dimension
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i, n[5] = {10, 20, 30, 40, 50};
        
    printf("Array one dimension.. \n\n");
    
    for(i=0; i<5; i++)
    {
        printf("n[%d] = %d\n", i, n[i]);
    }

    getchar();
    return 1;
}
