/*
/ Program: EX_0506.c
/ Purpose: Pass by Reference
*/

#include <stdio.h>
#include <conio.h>

// func_xy function
void func_xy(int *x, int *y)
{
     *x = *x + 10;
     *y = *y + 20;
}

// Main Function (Main Program)
int main (void)
{
    int i, j, k;
    
    i = 10;
    j = 20;
    
    printf("Start.. \n");
    printf("i = %d, j = %d\n\n", i, j);
    
    func_xy(&i ,&j);
    printf("Return1: i = %d\n", i);
    k = i + 20;    
	printf("k = %d\n\n", k);
	
	printf("Return2: j = %d\n",j);
    k = j + 30; 
	printf("k = %d\n", k);	
	
    getchar();
    return 1;
}
