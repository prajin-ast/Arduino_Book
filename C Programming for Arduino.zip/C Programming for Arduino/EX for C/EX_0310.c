/*
/ Program: EX_0310.c
/ purpose: & and && Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 10;	// 0000 1010 (binary number)
    b = 3;	// 0000 0011
    
    printf("\n& and && Operators\n\n");
    
    printf("a = %2d (0x%X)\nb = %2d (0x%X)\n\n", a, a, b, b);    
    
    printf("a & b = %2d (0x%X)\n", a & b, a & b);
    printf("a && b = %2d (0x%X)\n\n", a && 2, a && 2);
    			
    getchar();
    return 1;
}

