/*
/ Program: EX_0606_1.c
/ Purpose: String
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i=0;
    char str1[10] = "C for MCU";
    char str2[10] = { 'C', ' ', 'f', 'o', 'r', ' ', 'M', 'C', 'U' };
    
    printf("\nString (array character)\n\n");
    
    printf("char str1[10] = \"C for MCU\";\n\n");
    printf("str1: %s\n\n",str1);
    
    printf("char str2[10] = {'C',' ','f','o','r',' ','M','C','U'};\n\n");
    printf("str2: ");
    for(i=0; i<9; i++)
    {
        printf("%c",str2[i]);
    }    
    printf("\n");
    
    getchar();
    return 1;
}
