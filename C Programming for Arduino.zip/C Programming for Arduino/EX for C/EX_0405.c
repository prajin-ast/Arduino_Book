/*
/ Program: EX_0405.c
/ purpose: switch statement 
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a;

    a = 10;
    
    printf("\nswitch statement \n\n");
    printf("a = %d\n\n", a);
    
    printf("Start..\n\n");
    switch(a)
    {
		case 10:
			printf("case a is 10\n");
		break;
		case 3:
			printf("case a is 3\n");
		break;
		default:
			printf("No case..\n");
		break;
	}
	printf("\nEnd..\n");
		
    getchar();
    return 1;
}
