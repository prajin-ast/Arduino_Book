/*
/ Program: EX_0403.c
/ purpose: if ... else if statement
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;
    b = 3;
    c = 1;
    
    printf("\nif ... else if statement\n\n");
    printf("a = %d\nb = %d\nc = %d\n\n", a, b, c);
    
	printf("Start..\n\n");
    if (a > b)
    {
		printf("a > b is True\n\n");
	} else if (b > c)
	{
		printf("a > b is False\n");
		printf("but\n");
		printf("b > c is ture\n\n");
	}
	printf("End..\n");
		
    getchar();
    return 1;
}
