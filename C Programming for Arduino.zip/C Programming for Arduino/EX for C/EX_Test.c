#include <stdio.h>
#include <conio.h>

int main(void)
{
    int n[5];
    /*
    n[0] = 10;
    n[1] = 11;
    n[2] = 12;
    n[3] = 13;
    n[4] = 14;
    n[5] = 15;
    */
    /*
    printf("%d\n",n[0]);
    printf("%d\n",n[1]);
    printf("%d\n",n[2]);
    printf("%d\n",n[3]);
    printf("%d\n",n[4]);
    printf("%d\n",n[5]);
    */
        
    printf("%d\n", 1 % 4);
    printf("%d\n", 2 % 4);
    printf("%d\n", 3 % 4);
    printf("%d\n", 4 % 4);
    
    getchar();
}
