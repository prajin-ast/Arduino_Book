#include <stdio.h>
#include <conio.h>

int main(void)
{
    printf("File for test binary file%d\n", 1 % 4);
    getchar();
}
