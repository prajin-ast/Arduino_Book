/*
/ Program: EX_0602.c
/ Purpose: Array one dimension
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i, n[5];
        
    printf("Array one dimension.. \n\n");
    
    for(i=0; i<5; i++)
    {
        n[i] = 10 * (1+i);
        printf("n[%d] = %d\n", i, n[i]);
    }

    getchar();
    return 1;
}
