/*
/ Program: EX_Table6_1_strspn.c
/ Purpose: strspn
/ Ref:     Turbo C bible
*/
 
#include <stdio.h>
#include <conio.h>
#include <string.h>

// Main Function (Main Program)
int main (void)
{
    char s1[] = { "xza" };
		char s2[] = { "abc123456x789z0" };
		int i;
    i = strspn(s1, s2);
    printf("strspn : %d\n\n",i);
    
    printf("\n");
    
    getchar();
    return 1;
}
