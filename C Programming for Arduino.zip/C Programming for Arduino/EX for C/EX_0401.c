/*
/ Program: EX_0401.c
/ purpose: if statement
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 10;
    b = 3;
    
    printf("\nif statement\n\n");
    printf("a = %d\nb = %d\n\n", a, b);
    
	printf("Start..\n\n");
    if (a > b)
    {
		printf("a > b is True\n\n");
	}	
	printf("End..\n");
	
    getchar();
    return 1;
}
