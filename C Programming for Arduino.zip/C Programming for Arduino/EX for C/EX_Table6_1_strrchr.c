/*
/ Program: EX_Table6_1_strrchr.c
/ Purpose: strchr & strrchr
/ Ref:     Turbo C bible
*/
 
#include <stdio.h>
#include <conio.h>
#include <string.h>

// Main Function (Main Program)
int main (void)
{
    char str[] = { "10 abc at $1.20 ea. = $1.20 ae $abc" };
    char *str_tmp1;
		char *str_tmp2;
		int i;
				     
    str_tmp1 = strchr(str, '$');
    printf("strchr: %s\n\n",str_tmp1);
    str_tmp2 = strrchr(str, '$');
    printf("strrchr: %s\n\n",str_tmp2);
    
    printf("\n");
    
    getchar();
    return 1;
}
