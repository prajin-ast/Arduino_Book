/*
/ Program: EX_0607.c
/ Purpose: String
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    char str[15];
    int i;

    printf("\r\nInput a string :");
    gets(str);

    for(i=0; i<15; i++)
    {
        printf("%c",str[i]);
   	}
    puts("");      // new line & return
    printf("%s",str);
    
    getchar();
    return 1;
}
