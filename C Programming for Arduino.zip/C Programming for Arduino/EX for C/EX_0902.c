/*
/ program: EX_0902.c
/ purpose: Bits and Bytes
*/

#include <stdio.h>
#include <conio.h>

#include "EX_util_c.c"

typedef unsigned char BYTE;
typedef unsigned int WORD;

BYTE nibble_byte(BYTE *x)
{
    *x = ((*x<<4) | (*x>>4));
    return (*x);
}

WORD nibble_word(WORD *x)
{
    *x = ((*x<<8) | (*x>>8));
    return (*x);
}

int main(void)
{    
    BYTE x = 0x0F;      // "0x" is the hexadecimal formatter
    WORD xx = 0x00FF;
  
    printf("Swapping function\n\n");
    
    printf("X: 0x0F\n");
    printf("Byte SWAP => ");
    nibble_byte(&x);
    printf("X: 0x%X\n\n", x);    

    printf("X: 0x00FF\n");
    printf("Word SWAP => ");
    nibble_word(&xx);
    printf("X: 0x%X\n", xx);    
      
    getch();    
}
