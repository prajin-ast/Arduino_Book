/*
/ Program: EX_0610.c
/ Purpose: String
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i;
    char str[5][15];
    
    for(i=0; i<5; i++)
    {
        printf("\r\nInput a string :");
        gets(str[i]);
        puts(str[i]);
    }
    puts("");
    for(i=0; i<5; i++)
    {
        puts(str[i]);
        puts("");
    }
    
    getchar();
    return 1;
}
