/*
/ program: EX_1001.c
/ purpose: Open/Read/Write File
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
  FILE *in, *out;

  if ((in = fopen("bin01.exe", "rt")) == NULL)
  {
    fprintf(stderr, "Cannot open input file.\n");
    getch();
    return 1;
  }

  if ((out = fopen("bin02.exe", "wt")) == NULL)
  {
    fprintf(stderr, "Cannot open output file.\n");
    getch();
    return 1;
  }

  while (!feof(in))
    fputc(fgetc(in), out);

  printf("backup complete..\n");
  fclose(in);
  fclose(out);
   
  getch();
   
  return 0;
}
