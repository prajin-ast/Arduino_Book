/*
/ Program: EX_0406.c
/ purpose: while loop
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i;
	
	i = 0;
	
    printf("\nwhile loop\n\n");
    printf("i = %d\n\n", i);
        
    printf("Start..\n\n");    	
    while(i < 5)
    {
		printf("i = %d\n", i);
		i++;
	}
	printf("\nEnd..\n");
		
    getchar();
    return 1;
}
