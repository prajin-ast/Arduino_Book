/*
/ Program: EX_0305.c
/ purpose: Assignment Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

	printf("Simple Assignment\n");
    a = 10;
    b = 3;
	printf("a = %d\nb = %d\n", a, b);
    
	printf("\nCompound Assignment\n");
	a += b;
    printf("a = %d\n", a);
    		
    getchar();
    return 1;
}

