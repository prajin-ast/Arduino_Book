/*
/ program: EX_0904.c
/ purpose: Bits and Bytes
*/

#include <stdio.h>
#include <conio.h>

#include "EX_util_c.c"

typedef unsigned char BYTE;
typedef unsigned int WORD;

WORD bitRead(WORD x, WORD i)
{
    x = x >> i;
    x = x & 0x0001;
    return (x);
}

WORD bitWrite(WORD x, WORD n, char b)
{
    int m = 1;
    
    if (b == 1)
    {
        x = x | (m << n);
    } else
    {
        x = x & (~(m << n));
    }
    return (x);
}

int main(void)
{
    int i;
    WORD x = 0x73;      // 01110011 (binary formatter)
  
    printf("bitRead & bitWrite function\n\n");
    dsp_bit_pattern(x);
    
    for(i=7; i>=0; i--)
    {
        printf("Bit%d=%d, ", i, bitRead(x, i));
    }
    printf("\n\n");
 
    x = bitWrite(x, 2, 1);
    dsp_bit_pattern(x);
 
    for(i=7; i>=0; i--)
    {
        printf("Bit%d=%d, ", i, bitRead(x, i));
    }
      
    getch();    
}
