/*
/ program: EX_1004.c
/ purpose: Open/Read/Write Binary File
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
  FILE *in, *out;

  if ((in = fopen("bin01.exe", "r+b")) == NULL)
  {
    fprintf(stderr, "Cannot open input file.\n");
    getch();
    return 1;
  }

  if ((out = fopen("bin02.exe", "w+b")) == NULL)
  {
    fprintf(stderr, "Cannot open output file.\n");
    getch();
    return 1;
  }

  while (!feof(in))
    fputc(fgetc(in), out);

  printf("create complete..\n");
  fclose(in);
  fclose(out);
  getch();
   
  return 0;
}
