/*
/ Program: EX_0311.c
/ purpose: Conditional Operator
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;	// 0000 1010 (binary number)
    b = 3;	// 0000 0011
    
    printf("\nConditional Operator\n\n");
    
    printf("a = %2d\nb = %2d\n\n", a, b);    
    
    c = (a > b)? (a=a-b):(b=b-a); 
	printf("a = %d\nb = %d\nc = %d\n", a, b, c);
	
    getchar();
    return 1;
}
