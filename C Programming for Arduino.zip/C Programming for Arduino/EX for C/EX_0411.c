/*
/ Program: EX_0411.c
/ purpose: continue loop
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i = 0;
	
    printf("\nContinue loop\n\n");    
	    
    printf("Start.. loop\n\n");    	
    for(i=0; i<10; i++)
    {			
		if (i == 5)
		{
			printf("Continue..\n");
			continue;
		}				
		printf("i = %d\n", i);
	}
	printf("\nEnd.. loop\n");

    getchar();
    return 1;
}
