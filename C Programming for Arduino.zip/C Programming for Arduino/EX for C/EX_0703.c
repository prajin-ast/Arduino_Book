/*
/ Program: EX_0703.c
/ Purpose: Pointers Arrays
*/

#include <stdio.h>
#include <conio.h>

int num[10] = {0,1,2,3,4,5,6,7,8,9};

int main(void)
{
    int *iptr, i;
    iptr = num;
	
    printf("Pointers Arrays\n");
    for(i=0; i<10; i++)
    {
        printf("\nnum[%d] = %d ", i, *(iptr+i));
    }    
    getch();
}
