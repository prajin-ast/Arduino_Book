/*
/ Program: EX_0408.c
/ purpose: do while loop
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int i;
	
	i = 0;
	
    printf("\ndo while loop\n\n");    
    printf("i = %d\n\n", i);
	    
    printf("Start..\n\n");    	
    do
    {
		printf("i = %d\n", i);
		i++;
	} while(i<5);
	printf("\nEnd..\n");
		
    getchar();
    return 1;
}
