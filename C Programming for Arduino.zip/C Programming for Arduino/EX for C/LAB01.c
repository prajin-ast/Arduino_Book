#include <stdio.h>

int main(void)
{
  printf("My First Programming in C/C++");
  getch();
}
