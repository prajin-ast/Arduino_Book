/*
/ program: EX_0704.c
/ purpose: Pointers and Strings 
*/

#include <stdio.h>
#include <conio.h>
#include <string.h>

char *str[] = {"C Programming for Microcontroller"};

int main(void)
{
    char *cptr, i;

    cptr = str[0];
    printf("Pointers and Strings\n");
    
    for(i=0; i<strlen(*str); i++)
    {
        printf("%c", *(cptr+i));
    }
    getch();
}
