/*
/ Program: EX_0604.c
/ Purpose: Array two dimension
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i, j, k;
    int num[3][3];
   	        
    printf("Array two dimension.. \n\n");

    k = 0;
   	for(i=0; i<3; i++)
	{
      	for(j=0; j<3; j++)
		{
            num[i][j] = k++;
         	printf("num[%d][%d] = %d\n", i, j, num[i][j]);
      	}
      	printf("\n");
   	}
   	
    getchar();
    return 1;
}
