/*
/ Program: EX_0306.c
/ purpose: Relational Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 10;
    b = 3;
    
    printf("\nRelational Operators\n\n");
    printf("a = %d, b = %d\n\n", a, b);
	printf("a < b  = %d\n", a < b);
	printf("a <= b = %d\n", a <= b);
	printf("a > b  = %d\n", a > b);
	printf("a >= b = %d\n", a >= b);
	printf("a == b = %d\n", a == b);
	printf("!(a>b) = %d\n", !(a>b));
		
    getchar();
    return 1;
}

