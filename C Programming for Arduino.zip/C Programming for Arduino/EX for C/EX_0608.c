/*
/ Program: EX_0608.c
/ Purpose: String function
*/
 
#include <stdio.h>
#include <conio.h>
#include <string.h>	    // Standard string functions Header file

// Main Function (Main Program)
int main (void)
{
    char string1[27], string2[4];
    char *ptr;

    printf("String function\n\n");
    
    strcpy(string1,"abcdefghijklmnopqrstuvwxyz");
    strcpy(string2,"omn");

    printf("String1: %s\n",string1);
    printf("Search:  \"omn\"\n\n");
    
    printf("strpbrk function\n");
    ptr = strpbrk(string1, string2);    
    if(ptr)
    {        
        printf("Found first character: %c\n", *ptr);
    } else {
        printf("Didn't find character in set\n");
    }

    getchar();
    return 1;
}
