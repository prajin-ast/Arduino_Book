/*
/ program: EX_1002.c
/ purpose: fwrite, fgets function
*/

#include <string.h>
#include <stdio.h>

int main(void)
{
  FILE *f;
  char str1[] = "fwrite, fgets\n";
  char str2[] = "function demo";
  char msg[20];
  int str_len;
  
  f = fopen("data02.txt", "w+");
  if (f == NULL)
  {
    printf("Cannot create File\n");
    getch();
    return 1;
  }
  str_len = strlen(str1) + strlen(str2);
  
  fwrite(str1, strlen(str1), 1, f);
  fwrite(str2, strlen(str2), 1, f);
  fseek(f, 0, SEEK_SET);  
  while(fgets(msg, str_len+1, f) != NULL)
  {
    printf("%s", msg);
  }
  
  fclose(f);
  getch();
   	
  return 0;
}
