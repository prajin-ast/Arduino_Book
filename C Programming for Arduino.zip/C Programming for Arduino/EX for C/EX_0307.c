/*
/ Program: EX_0307.c
/ purpose: Logical Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;
    b = 3;
    c = 1;
    
    printf("\nLogical Operators\n\n");
    printf("a = %d, b = %d, c = %d\n\n", a, b, c);
	printf("(a > b) && (b < a) = %d\n", (a > b) && (b < a));
	printf("(a > b) && (b < c) = %d\n", (a > b) && (b < c));
	printf("(a < b) && (b < c) = %d\n\n", (a < b) && (b < c));
	
	printf("(a > b) || (b < a) = %d\n", (a > b) || (b < a));
	printf("(a > b) || (b < c) = %d\n", (a > b) || (b < c));
	printf("(a < b) || (b < c) = %d\n\n", (a < b) || (b < c));

	printf("!(a > b) = %d\n", !(a > b));
	printf("!(b < c) = %d\n", !(b < c));
			
    getchar();
    return 1;
}

