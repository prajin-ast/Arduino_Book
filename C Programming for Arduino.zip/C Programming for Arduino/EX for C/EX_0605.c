/*
/ Program: EX_0605.c
/ Purpose: Array two dimension
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i, j, k;
    int num[3][3] = { 1, 2, 3,
                      4, 5, 6,
                      7, 8, 9, 
                    };
   	        
    printf("Array two dimension.. \n\n");

    k = 0;
   	for(i=0; i<3; i++)
	{
      	for(j=0; j<3; j++)
		{
         	printf("num[%d][%d] = %d\n", i, j, num[i][j]);
      	}
      	printf("\n");
   	}
   	
    getchar();
    return 1;
}
