/*
/ program: EX_0901.c
/ purpose: Bits and Bytes
*/

#include <stdio.h>
#include <conio.h>

#include "EX_util_c.c"

typedef unsigned char BYTE;

BYTE rotate_left(BYTE *x, BYTE i)
{
    for(; i>0; i--)
    {
        *x = ((*x<<1) | (*x>>7));
    }
    return (*x);
}

BYTE rotate_right(BYTE *x, BYTE i)
{
    for(; i>0; i--)
    {
        *x = ((*x>>1) | (*x<<7));
    }
    return (*x);
}

int main(void)
{    
    BYTE x = 1;      // "0x" is the hexadecimal formatter
    BYTE i;
  
    printf("rotate left/right function\n\n");
    
    printf("Data(binary): ");
    dsp_bit_pattern(x);
    
    printf("\nrotate left\n");
    for(i=0; i<7; i++)
    {
        rotate_left(&x, 1);
        dsp_bit_pattern(x);                               
    }

    printf("\nrotate right\n");
    for(i=0; i<7; i++)
    {
        rotate_right(&x, 1);
        dsp_bit_pattern(x);                               
    }
      
    getch();    
}
