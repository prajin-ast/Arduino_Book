/*
/ Program: EX_0304.c
/ purpose: Increment Decrement Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 10;
    b = 3;

	printf("Increment Operators\n");
	printf("a = %d (begin)\n", a);
    printf("a = %d (with a++)\n", a++);
    printf("a = %d (after)\n", a);
    printf("a = %d (with ++a)\n", ++a);
    printf("a = %d (end)\n", a);
    
	printf("\nDecrement Operators\n");
	printf("b = %d (begin)\n", b);
    printf("b = %d (with b--)\n", b--);
    printf("b = %d (after)\n", b);
    printf("b = %d (with --b)\n", --b);
    printf("b = %d (end)\n", b);
    		
    getchar();
    return 1;
}

