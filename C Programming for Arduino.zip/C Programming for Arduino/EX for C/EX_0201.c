/*
/ Program: EX_0201.c
/ Purpose: scope variables
*/

#include <stdio.h>
#include <conio.h>

// function prototypes
void func1(void);
void func2(void);

int i;				// Global variables

void func1(void)
{
	int i;			// Local variables

	i = 50;
	func2();
	printf("func1() i = %d\n",i);
}

void func2(void)
{
	int i;			// Local variables

	i = 20;
	printf("func2() i = %d\n",i);
}

int main()
{
	printf("scope variables\n\n");
	i = 100;		// Local variables
	func1();
	printf("main()  i = %d\n",i);
	getchar();
}
