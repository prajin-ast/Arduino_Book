/*
/ Program: EX_0303.c
/ purpose: Arithmetic & Unary Operators
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;
	float c;

    a = 10;
    b = 3;

    c = a * b;  // Multiplication Operation
    printf("c = %.0f\n", c);
    
    c = (float) a /b;  // Division Operation (with Cast operator)
    printf("c = %.2f\n", c);
    
    c = a % b;	// Modulo Operation
	printf("c = %.0f\n", c);
		
    getchar();
    return 1;
}

