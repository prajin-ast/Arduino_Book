/*
/ program: EX_0801.c
/ purpose: Structure variables
*/

#include <stdio.h>
#include <conio.h>

struct mcu { 
    char name[20];
    int price;
    };

int main(void)
{
    int i;
    struct mcu avr, pic;	
    struct mcu controller[5];
    
    strcpy(avr.name, "mega128");
    avr.price = 120;
    strcpy(pic.name, "16F887");
    pic.price = 150;
    
    printf("Structure variables\nMicroController price\n\n");
    printf("%-9s prie:%5d B\n",avr.name, avr.price);
    printf("%-9s prie:%5d B\n",pic.name, pic.price);
    
    strcpy(controller[0].name, "MCS-51");
    controller[0].price = 100;
    strcpy(controller[1].name, "dsPIC");
    controller[1].price = 120;
    strcpy(controller[2].name, "PIC32");
    controller[2].price = 140;
    strcpy(controller[3].name, "Propeller");
    controller[3].price = 160;
    strcpy(controller[4].name, "Arduino");
    controller[4].price = 180;
    
    for(i=0; i<5; i++)
    {
        printf("%-9s prie:%5d B\n",controller[i].name, controller[i].price);
    }
    
    getchar();    
}
