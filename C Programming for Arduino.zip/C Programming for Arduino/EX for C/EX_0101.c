/*
/ Program: EX_0101.c
/ Purpose: Structure of a C Program
*/

// Preprocessor directives (.h-file (header file))
#include <stdio.h>    // standard I/O 
#include <conio.h>    // console I/O

// Function add_num
float add_num(float n1, float n2)	
{
  float n;            // Declarations
  n = n1 + n2;        // Expressions
  return n;  
}

// Function display_num
void display_num(float n)
{
  printf("Number: %0.2f\n",n);    // call function
}

// Main Function (Main Program)
int main(void)						
{
  float num;                // Declarations
  int i;                    // Declarations
  int total = 5;				    // Definitions
        
  for(i=0; i<total; i++)		// Statements
  {
    num = add_num(10, i);     // call function
    display_num(num);
  }
    
  getchar();   
}
