/*
/ program: EX_0903.c
/ purpose: Bits and Bytes
*/

#include <stdio.h>
#include <conio.h>

typedef unsigned char BYTE;
typedef unsigned int WORD;

BYTE lowByte(WORD x)
{
    return (x);
}

BYTE highByte(WORD x)
{
    x = x >> 8;
    return (x);
}

int main(void)
{
    WORD x = 0xAABB;  // "0x" is the hexadecimal formatter
  
    printf("lowByte & highByte function\n\n");
    printf("Low byte of 0xAABB is ");
    printf("%X\n", lowByte(x));
  
    printf("High byte of 0xAABB is ");
    printf("%X", highByte(x));
  
    getch();    
}
