/*
/ Program: EX_0402.c
/ purpose: if...else statement
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b;

    a = 3;
    b = 10;
    
    printf("\nif...else statement\n\n");
    printf("a = %d\nb = %d\n\n", a, b);
    
	printf("Start..\n\n");
    if (a > b)
    {
		printf("a > b is True\n\n");
	} else 
	{
		printf("a > b is False\n\n");
	}
	printf("End..\n");
		
    getchar();
    return 1;
}
