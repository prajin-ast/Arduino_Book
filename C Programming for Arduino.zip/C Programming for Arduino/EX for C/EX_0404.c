/*
/ Program: EX_0404.c
/ purpose: if...else if...else statement
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int a, b, c;

    a = 10;
    b = 3;
    c = 1;
    
    printf("\nif...else if...else statement\n\n");
    printf("a = %d\nb = %d\nc = %d\n\n", a, b, c);
    
	printf("Start..\n\n");
    if (a > b)
    {
		printf("a > b is True\n\n");
	} else if (b > c)
	{
		printf("b > c is True\n\n");
	} else {
		printf("a > b and b > c is False\n\n");
	}
	printf("End..\n");
	
    getchar();
    return 1;
}
