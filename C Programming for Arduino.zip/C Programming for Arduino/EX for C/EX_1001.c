/*
/ program: EX_1001.c
/ purpose: Open/Read/Write File
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
  FILE *in, *out;

  if ((in = fopen("data01.txt", "rt")) == NULL)
  {
    fprintf(stderr, "Cannot open input file.\n");
    getch();
    return 1;
  }

  if ((out = fopen("data01.bak", "wt")) == NULL)
  {
    fprintf(stderr, "Cannot open output file.\n");
    getch();
    return 1;
  }

  while (!feof(in))
    fputc(fgetc(in), out);

  printf("backup complete..\n");
  fclose(in);
  fclose(out);
   
  getch();
   
  return 0;
}
