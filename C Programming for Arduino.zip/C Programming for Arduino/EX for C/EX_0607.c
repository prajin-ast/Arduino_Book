/*
/ Program: EX_0607.c
/ Purpose: String
*/
 
#include <stdio.h>
#include <conio.h>

// Main Function (Main Program)
int main (void)
{
    int i;
    char str1[][12] = { "C Program ",
                        "for MCU", 
                      };
    
    printf("\nString (array character)\n\n");
    
    printf("str1[0]: %s\n",str1[0]);
    printf("str1[1]: %s\n\n",str1[1]);
    
    printf("%s%s\n\n",str1[0],str1[1]);
    
    printf("\n");
    
    getchar();
    return 1;
}
