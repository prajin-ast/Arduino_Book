/*
/ Program: EX_0701_1.c
/ Purpose: Pointers
*/

#include <stdio.h>
#include <conio.h>

int main(void)
{
    int *iptr, num;

    printf("Sizeof variables\n");
    printf("iptr = %X\n",sizeof(iptr));
    printf("num  = %X\n",sizeof(num));
    iptr = 10;
    printf("\nPointers\n");
    printf("Address of iptr = %X\n",iptr);
    printf("Address of iptr = %X\n",&iptr);
    printf("Address of num  = %X\n",&num);
    
    iptr = &num;
    printf("\niptr = %X\n",&iptr);    
    num = 20;
    printf("num  = %d\n",num);

    *iptr = 50;
    printf("\n*iptr = %d\n",*iptr);    
    printf("num   = %d\n",num);
    
    getch();
}