/*
/ Program: EX_0304.c
/ Purpose: Main&Sub function
*/

#include <stdio.h>
#include <conio.h>

// Line function
void line(char ch)
{
	int i;
	for(i=0; i<23; i++)
	{
		printf("%c", ch);
	}		
	printf("\n");
}

// Main Function (Main Program)
int main (void)
{
	line('-');
	printf("Main Function...\n");
	line('=');
	printf("number 1...\n");
	line('=');
	printf("number 2...\n");
	line('-');
	
    getchar();
    return 1;
}
